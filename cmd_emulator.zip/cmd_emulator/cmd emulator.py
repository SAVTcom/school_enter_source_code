import sys
from progress.bar import *
from progress import *
from progress.spinner import *
import time
from tqdm import tqdm
from tqdm import trange
from os.path import *
import threading
import os


installing=False
drivers1=False
drivers=False
install=False

if sys.platform=="win32":
    print("Check windows... ok")
else:
    quit(1)

diskPath=abspath("./files/disks/")
Cpath=diskPath+"\\C"
Dpath=diskPath+"\\D"
winPath=Cpath+"\\Windows"

bar=Spinner("Checking os... ")
for i in range(50):
    bar.next()
    time.sleep(0.1)

if isdir("./files/disks"):
    if isdir("./files/disks"):
        for i in range(15):
            bar.next()
            time.sleep(0.1)
        if isdir(Cpath) and isdir(Dpath):
            if isdir(winPath):
                for i in range(15):
                    bar.next()
                    time.sleep(0.1)
                if isdir(winPath+"\\System") and isdir(winPath+"\\System32"):
                    if isfile(winPath+"\\System\\readme.txt"):
                        file=open(winPath+"\\System\\readme.txt","r")
                        if file.read()=="Don't delete system files!":
                            file.close()
                            if isfile(winPath+"\\System32\\sys.pysl"):
                                file=open(winPath+"\\System32\\sys.pysl","r")
                                if file.read()=="sys open cmd; get commands,drivers;end":
                                    file.close()
                                    if isdir(winPath+"\\drivers"):
                                        if isfile(winPath+"\\drivers\\dr.sd"):
                                            drivers1=True
                                        else:
                                            install=True
                                    else:
                                        install=True
                                else:
                                    file.close()
                                    install=True
                        else:
                            file.close()
                            install=True
                    else:
                        install=True
                else:
                    install=True
            else:
                install=True
        else:
            install=True
    else:
        install=True
else:
    install=True


bar.finish()

if install==True:
    print("System not installed or damaged!")
    if input("Install ? (Y)")=="Y":
        install=False
        installing=True
    else:
        quit(1)

if installing==True:
    try:
        os.system("rmdir "+diskPath+"/q /s")
    except:
        pass

    print("Cleaned... done")
    bar=Bar("Copying files... ",max=100)
    for i in range(20):
        bar.next()
        time.sleep(0.1)

    pysl="sys open cmd; get commands,drivers;end"
    readme="Don't delete system files!"
    time.sleep(5)
    for i in range(80):
        bar.next()
        time.sleep(0.1)
    bar.finish()

    bar=Spinner("Create files structure... ")
    for i in range(20):
        bar.next()
        time.sleep(0.1)

    try:
        os.mkdir(diskPath, mode=0o777,  dir_fd=None)
    except:
        pass
    try:
        os.mkdir(Dpath, mode=0o777, dir_fd=None)
    except:
        pass
    try:
        os.mkdir(Cpath, mode=0o777,  dir_fd=None)
    except:
        pass
    try:
        os.mkdir(winPath, mode=0o777, dir_fd=None)
    except:
        pass
    try:
        os.mkdir(winPath+"\\System", mode=0o777, dir_fd=None)
    except:
        pass
    try:
        os.mkdir(winPath+"\\System32", mode=0o777, dir_fd=None)
    except:
        pass
    try:
        os.mkdir(winPath+"\\drivers", mode=0o777, dir_fd=None)
    except:
        pass
    time.sleep(2)
    for i in range(50):
        bar.next()
        time.sleep(0.1)

    file=open(winPath+"\\drivers\\dr.sd","w",encoding="UTF-8")
    file.write("getDrive(mouse,keyboard,monitor)")
    file.close()
    file=open(winPath+"\\System\\readme.txt","w",encoding="UTF-8")
    file.write(readme)
    file.close()
    file=open(winPath+"\\System32\\sys.pysl","w",encoding="UTF-8")
    file.write(pysl)
    file.close()
    bar.finish()

    pbar = tqdm(["path sys","system dirs","drivers","cmd","emulator files"])
    for char in pbar:
        time.sleep(1)
        pbar.set_description("Installing %s" % char)


