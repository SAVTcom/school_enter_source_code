import colorama
from colorama import Fore,Back,Style
import datetime,time
import random as rd

choice=0

colorama.init()

date=str(datetime.date.today())
month=int(date[date.find("-")+1:date.rfind("-"):])
day=int(date[date.rfind("-")+1:])
hny=False

tree="""                     ¶¶¶
                    ¶¶1¶¶
                 ¶¶¶¶   ¶¶¶¶
                   ¶     ¶
                  ¶¶¶111¶¶¶
                 ¶¶¶¶¶¶¶¶¶¶¶
               1¶¶11¶111111¶¶1
              ¶¶¶111111111111¶¶
            ¶¶¶111111111¶¶¶¶¶1¶¶¶
          1¶¶¶¶¶11111111¶1  1¶11¶¶¶
         ¶¶¶¶1 1¶¶111111¶¶ 1¶¶¶1¶¶¶¶
           ¶¶  1¶¶1111111¶¶¶1¶¶¶
           ¶¶¶¶¶111111111111111¶¶
          ¶¶11¶¶1111111111111111¶¶¶
        ¶¶¶11111111111111111111111¶¶¶
       ¶¶¶11111111111111111111¶11111¶¶1
     ¶¶¶1111111111111111111111¶¶¶1111¶¶¶
    ¶¶¶¶¶1¶¶111111111111111¶¶¶1 1¶¶1¶¶¶¶¶1
         ¶¶¶1111111111111111¶¶  1¶¶¶
       1¶¶111¶¶¶1111111111111¶¶¶¶¶1¶¶¶
      ¶¶¶11¶¶¶11¶¶¶11111111111¶111111¶¶1
    ¶¶¶1111¶¶1  1¶11111111111111111111¶¶¶
  ¶¶¶11111111¶¶¶¶¶1111111111111111111111¶¶¶
1¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶111111111¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
¶¶¶¶¶¶¶¶¶¶¶¶¶1¶¶¶1¶¶¶¶¶¶¶¶¶1¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶
                  1¶¶¶¶¶¶¶1
                  1¶¶¶¶¶¶¶¶
                  1¶¶¶¶¶¶¶¶
                  1¶¶¶¶¶¶¶¶
                  1¶¶¶¶¶¶¶¶
                  1¶¶¶¶¶¶¶¶
                  1¶¶¶¶¶¶¶¶
                  ¶¶¶¶¶¶¶¶¶"""

if (day>20 or day<16) and (month==12 or month==1):
    hny=True

while True:
    print(Fore.YELLOW+"**************")
    print(Fore.YELLOW+"*"+Fore.RED+"school enter"+Fore.YELLOW+"*")
    print(Fore.YELLOW+"**************")

    print()
    print(Fore.GREEN+"v0.1 BETA TEST")
    print()


    print()



    print()
    if hny:print(tree)

    print("\n")
    #0-exit 1-math
    while True:
        print(Fore.CYAN+"    Выбери предмет!\n      0-Выход\n      1-Математика\n      Coming soon...")
        choicein=input("?>")
        if choicein.isdigit():
            if choicein=="0":
                choicein=0
                quit(1)
            elif choicein=="1":
                choice=1
                del choicein
                break

    print("\n\n")
    if choice==1:
        while True:
            print(Fore.BLUE+"Выбрана математика!\n\n")
            while True:
                print(Fore.CYAN+"  Выбери тип практики!\n    0-назад\n    1-учимься считать\n\n")
                control=input("?>")
                if control=="0":
                    i=0
                    break
                elif control=="1":
                    i=1
                    break

            if i==0:
                break
            elif i==1:
                print(Fore.BLUE+"\n\nВыбран тип практики учимься считать!\n\n")
                while True:
                    print(Fore.CYAN+"  Выбери тип практики!\n    0-легко(Простые примеры на сложение и вычитание)\n    1-нормально(Не сделано)\n    2-сложно(Не сделано)\n    3-Пиздец балди бежит!(Не сделано)")
                    control=input("?>")
                    if control=="0":
                        j=0
                        break
                if j==0:
                    print(Fore.BLUE+"\n\n\n\n\nВыбрана лёгкая сложность!")
                    print(Style.RESET_ALL)
                    score=0
                    anti_score=0
                    alls=rd.randint(5,10)
                    znaks=["-","+"]
                    while (anti_score+score)<=alls:
                        print("Logs:\nGeneration... ok\n\n")
                        time.sleep(1)
                        znak=rd.choice(znaks)
                        one=rd.randint(1,400)
                        two=rd.randint(1,400)
                        pr=str(one)+znak+str(two)
                        prot=eval(pr)
                        print(str(pr))
                        ot=input("Ответ>")
                        try:
                            if int(ot)==int(prot):
                                print("Правильно!")
                                score+=1
                            else:
                                print("Неправильно!")
                                print(str(prot))
                                anti_score+=1
                        except:
                            print("Неправильно!")
                            print(str(prot))
                            anti_score+=1
                    print("\n\n--------------\nПравильно: "+str(score)+"\nНеправильно: "+str(anti_score)+"\nВсего примеров: "+str(alls))

