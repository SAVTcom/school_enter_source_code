import shelve as sh
import os
from progress import bar
from progress import spinner
from time import sleep
from random import randint
import colorama
from colorama import Fore, Back, Style
colorama.init()

"""
vb=spinner.Spinner("Get account ")
for i in range(100):
    sleep(0.1)
    vb.next()
"""

while True:
    print(Fore.YELLOW+'****************************')
    print(Fore.YELLOW+"*"+Fore.RED+"Приветствую в savt casino!"+Fore.YELLOW+"*")
    print(Fore.YELLOW+'****************************')
    print()
    print("V0.1")
    print("\n\n")
    print(Fore.CYAN+"Во что сыграем?\n   -1 - выход\n   0- кости\n\n",end="")

    while True:
        gametype=input("?>")
        if gametype=="-1":
            quit(1)
        if gametype.isdigit():
            if gametype=="0":
                gametype=0
                break

    print(Style.RESET_ALL)
    print("Игра запущена!\n\n")
    print("Logs:")
    print("Generation money started...",end="")
    money=randint(250,600)
    sleep(1)
    print("  ok")
    print("Get cube style...",end="")
    sleep(2.5)
    print("  ok")
    sleep(4)
    print("\n\n\n")

    while True:
        if money<70:
            print(Fore.RED+"Ты проиграл!")
            break
        print(Fore.GREEN+str(money)+"$")
        print(Fore.BLUE+"Введи ставку $>",end="")
        st=input()
        print(Fore.YELLOW+"Ставка "+st)
        if st.isdigit():
            if int(st)==0:
                print(Fore.YELLOW+"Ты не можешь поставить 0$!")

            elif int(st)<=money:
                cube=randint(1,6)
                cube1=randint(1,6)
                print(Fore.BLUE+"     ___________\n     |    "+str(cube)+"    |\n     ___________")
                print(Fore.RED+"     ___________\n     |    "+str(cube1)+"    |\n     ___________")
                if cube>cube1:
                    print(Fore.GREEN+"Ты выйграл "+st+"$!")
                    money+=int(st)
                elif cube<cube1:
                    print(Fore.RED+"Ты проиграл "+st+"$!")
                    money-=int(st)
                else:
                    print(Fore.CYAN+"Ничья!")
